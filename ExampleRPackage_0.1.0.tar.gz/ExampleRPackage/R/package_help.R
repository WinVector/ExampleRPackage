#' ExampleRPackage: Evocative Package Title (Title Case)
#'
#' Short description of why one should use this package.
#' Used by CRAN, so check their rules on "Writing R Extensions"
#' \url{https://cran.r-project.org/doc/manuals/r-release/R-exts.html}.
#'
#'
#' @docType package
#' @name ExampleRPackage
NULL
