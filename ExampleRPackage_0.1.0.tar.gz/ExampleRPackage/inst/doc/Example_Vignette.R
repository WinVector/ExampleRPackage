## -----------------------------------------------------------------------------
library(ExampleRPackage)

example_function(2)

