

val <- example_function(3, delta = 2)
expect_equal(5, val)

